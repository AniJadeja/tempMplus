#!/bin/sh

# Clone the Git repository into the container
git clone https://github.com/AniJadeja/tempMplus.git /mplus

# Change directory to the cloned repository

rm -r tempMplus

cp ./.env /tempMplus
# Verify that the repo is cloned and if not then clone it
if [ ! -d "$REPO_DIR/.git" ]; then
    # Clone the Git repository into the container
    git clone https://github.com/AniJadeja/tempMplus.git "$REPO_DIR"

    # Change directory to the cloned repository
    cd "$REPO_DIR"

    # Verify that the repository contains a package.json file
    if [ ! -f "package.json" ]; then
        echo "Error: package.json not found in repository"
        exit 1
    fi

    # Install dependencies
    npm install
fi
# # Verify that the repository contains a package.json file
# if [ ! -f "package.json" ]; then
#   echo "Error: package.json not found in repository"
#   exit 1
# fi

# Install dependencies
npm install

# Start the application
npm run dev
